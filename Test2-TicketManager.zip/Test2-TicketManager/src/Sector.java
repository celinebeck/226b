public enum Sector {
    CURVE,GRANDSTAND
}
