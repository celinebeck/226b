package ch.samt.talentshow;

public interface Show {
    void descriptionShow();
    float finalVote();
}
